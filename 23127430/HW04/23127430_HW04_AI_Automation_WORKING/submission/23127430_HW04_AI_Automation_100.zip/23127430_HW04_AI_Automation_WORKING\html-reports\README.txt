HW04 PLAYWRIGHT HTML REPORTS - LIGHTWEIGHT SUBMISSION PACKAGE
=============================================================

Student ID: 23127430
Branch: 23127430-HW04

Included canonical reports (9):

- fr01/chromium/index.html
- fr01/firefox/index.html
- fr01/webkit/index.html
- fr07/chromium/index.html
- fr07/firefox/index.html
- fr07/webkit/index.html
- fr13/chromium/index.html
- fr13/firefox/index.html
- fr13/webkit/index.html

Each report retains its result summary, test details, error-context Markdown,
and failure screenshots. Open the corresponding index.html in a browser.

Excluded to meet the submission size limit:

- Playwright trace ZIP attachments (*.zip)
- Repeated trace-viewer static folders (trace/)
- The diagnostic FR07 Firefox TC008 rerun

The exclusions do not change pass/fail totals. Trace buttons in the lightweight
copy may be unavailable because trace attachments are intentionally omitted.
The complete original evidence remains in the repository's html-reports folder.
